package com.pc2.Fundamentos.entity;

import lombok.Data;

@Data
public class Query {
    public String url;
    public String code;

}
