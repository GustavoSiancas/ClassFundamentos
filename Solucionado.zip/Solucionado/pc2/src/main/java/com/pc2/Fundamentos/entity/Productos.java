package com.pc2.Fundamentos.entity;


import lombok.Data;

@Data
public class Productos {
    public String Categoria;
    public String Codigo;
    public String Descripcion;
    public Float PrecioSol;
    public String Presentacion;
}
